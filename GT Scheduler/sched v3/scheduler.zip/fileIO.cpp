#include "fileIO.h"


fileIO::fileIO(){

	//cout<<"helloworld"<<endl;
}

void fileIO::readCourseFile(string filename){ // reads in from a .csv file generated from excel for the COURSE FILE.  I used openoffice to generate the csv file (shouldnt matter but thats how it was tested)
	int counter = 0; // counter to pick which column to store (0 for classname, 4 for prof name, 7 for sch)
	int intValue;

	ifstream file(filename); //opens the csv file
	string value = "";
	 
	for (int i=0;i<6;i++){ // gets rid of labels
		getline(file,value,','); 
	}
	getline(file,value,'\n'); // to next line
	counter =0;

	while(file.good()){ // while more lines to read
		for (int i=0;i<6;i++){
			getline(file,value,','); // gets next block
			if (counter==0){ // first one = class name--> add to list
				//cout<<"\tadd|"<<value<<"|to class"<<endl;
				classNameList.push_back(value); 
			}else if(counter == 4){ //fifth one = prof name --> add to list
				//cout<<"\tadd|"<<value<<"|to prof"<<endl;
				classProfList.push_back(value);
			}
			counter++;
		}
		getline(file,value,'\n');
		//classHoursList.push_back(value);
		//cout<<"value here is "<<value<<endl;
		istringstream(value) >>intValue; // puts number in the string to the integer version "313" becomes 313
		classHoursList.push_back(intValue);
		counter = 0;
	}
	
	classProfList.pop_back(); // removes ending since theres a extra line in csv
	classNameList.pop_back();
	classHoursList.pop_back(); 
	//cout<<classProfList.size()<<endl;
	//value= classNameList[0];
	/*for (int i=0;i<classNameList.size();i++){
		cout<<classNameList[i]<<endl;
		cout<<classProfList[i]<<endl;
		cout<<classHoursList[i]<<endl;
	}*/
}

