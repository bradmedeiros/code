#include <iostream>
#include <fstream>
#include <list>
#include <vector>
#include <sstream>
#include <string>



//#define DEBUG 1;
using namespace std;

class fileIO{

	//next to do: read the summer students in, put gtid,and then the
	//courses they want if theyre essential
	// then after this create a class to generate conflict matrix
private:	
	//std::list<int> alist;

	//these three come from the classlist csv from excel
	std::vector<string> classNameList;
	std::vector<string> classProfList;
	std::vector<int> classHoursList;
	
	//these four come from the summerstudent csv from excel
	std::vector<int> gtID; //the gtid of the student 
	std::vector<string> course1; //lists the absolutely desired classes for each student
	std::vector<string> course2; 
	std::vector<string> course3;
	std::vector<string> course4;
	

	
public:
	fileIO();
	void readCourseFile(string filename);
	
};