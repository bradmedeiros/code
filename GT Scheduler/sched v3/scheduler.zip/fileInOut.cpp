#include "fileInOut.h"


fileInOut::fileInOut(){


}
void fileInOut::print(){
	cout<<"hello world"<<endl;
}

