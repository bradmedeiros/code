#include <iostream>
#include <fstream>
#include <string>
//#include "gtclass.h"
#include "schedule.h"
#include "fileIO.h"
//#define DEBUG 1

using namespace std;


#define DEBUG 1

int main(){
#ifdef DEBUG
	 //cout<<"debug mode"<<endl;
#endif 

#ifndef DEBUG
	 //cout<<"debug mode off"<<endl;
#endif 

	//gtclass a;
	//fileIO a;
	//a.readCourseFile("summerCourses.csv");
	 //c.print();

	/* ifstream file("classestest.csv");
	 string value = "Hello world";
	 
	 while(file.good()){
		 getline(file,value,',');
		cout<<value<<endl;
		//cout<<"value is "<<value<<endl;
	//	cout<<string(value,1,value.length()-2);
	 }*/
/*	int time;
	gtclass obj(1,5);
	gtclass obj1(2,2);
	gtclass obj2(3,1);
	gtclass obj3(4,4);
	gtclass obj4(5,6);
	gtclass obj5(6,4);
	
	schedule a;
	a.addClass(2,3,&obj);
	a.addClass(2,3,&obj);
		a.addClass(2,3,&obj);
		a.addClass(2,3,&obj);
		a.addClass(2,3,&obj);
		a.addClass(2,3,&obj);
		a.addClass(2,3,&obj);
	
	//if(!a.addClass(2,0,3,&obj)){
	//	cout<<"ucce"<<endl;
	//}
	a.printInfo();
	a.exportOutput();
	cin.get();

	//gtclass
	/*void printInfo();
	void setTime(int day, int hour);
	int getTime(int day);
	int getHours(){return hours;}
	int getclassID(){return classID;}*/

	//schedule
	/*schedule();
	int addClass(int day, int tier,int hour, gtclass* gtclass);
	*/


	//obj.printInfo();
	//obj.setTime(0,10);
	//obj.setTime(1,7);
	//obj.setTime(2,3);
	 //obj.setTime(3,4);
	 
	//time = obj.getTime(3);
//	cout<<time<<endl;
	//cout<<obj.tostring();
	cin.get();
	return 0;

}