#include "schedule.h"
#define offset(a,b,c) ((a*24*6)+(b*24)+c)

schedule::schedule(){
#ifdef DEBUG 
	cout<<"schedule created"<<endl;
#endif 
	for (int i=0;i<24*4*6;i++){
		backbone[i] = NULL;
	}

}
int schedule::addClass(int day, int hour, gtclass* gtclass){
	int duration = gtclass->getHours();
	int tier = 0;
	for (int i=0;i<duration;i++){
		if (getClass(day,tier,hour+i)!=NULL){
			tier++;
			i = 0;
		}
		
	}
	if (tier > 5){return 0;}
	
	addClass(day,tier,hour,gtclass);
	return 1;
}



int schedule::addClass(int day, int tier, int hour, gtclass* gtclass){

	//int classTime[4];
	//int hours;
	//int classID;
	int duration = gtclass->getHours();
	
	for (int i=0;i<duration;i++){
		if (backbone[offset(day,tier,hour+i)]!=NULL || day >3 || tier > 6){
			return 0;
		}
		backbone[offset(day,tier,hour+i)] = gtclass;
		gtclass->setTime(day,hour);
	}

#ifdef DEBUG
	for (int i=0;i<24*4*6;i++){
		if (backbone[i] !=NULL){
			cout<<backbone[i]->getclassID()<<"  "<<endl;
		}
		
	}
#endif 

	return 1;
}

gtclass* schedule::getClass(int day, int tier, int hour){
	return backbone[offset(day,tier,hour)];
}

void schedule::printInfo(){
	cout<<"-------------"<<endl<<endl;
	for (int i=0;i<24;i++){
		cout<<" "<<i;
		if (i%2==0){cout<<":00";}
		if (i%2!=0){cout<<":30";}
		cout<<" ";
		if (i==23){cout<<endl<<endl;}
	}
	for (int i=0;i<24*4*6;i++){
		if (backbone[i]!=NULL){
			cout<<backbone[i]->getclassID()<<" ";
		}else{
			cout<<" 0 ";
		}

		if (i%24==0){cout<<endl;}
		if (i%(24*6)==0){cout<<endl<<endl;}
		
	}

}


void schedule::exportOutput(){
	gtclass* gtclass = NULL;
	cout<<"Output Exported"<<endl;
	ofstream outputFile;
	outputFile.open("output.txt");

	for (int day =0;day<4;day++){
		for (int tier = 0;tier<6;tier++){
			for (int hour=0;hour<24;hour++){
				gtclass = getClass(day,tier,hour);
				if (gtclass!=NULL){
					outputFile<<gtclass->getclassID()<<"|";
				}else{
					outputFile<<"0"<<"|";
				}
				
			}
			outputFile<<",";  //signifies new tier
		}
		outputFile<<"."; //signifies new day
	}
	
	outputFile<<"%";  //signifies EOF 
	outputFile.close();
}

/*rivate:	
	
	gtclass* backbone[24*4*4 ];
public:
void printInfo();
	void setTime(int day, int hour);
	int getTime(int day);
	int getHours(){return hours;}
	int getclassID(){return classID;}
	schedule();
	int addClass(int day, int tier,int hour, gtclass* gtclass);
	void printInfo();
	*/

