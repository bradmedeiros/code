#include <iostream>
#include <fstream>
#include "gtclass.h"
#define DEBUG 1;
using namespace std;

class schedule{

private:	
	
	gtclass* backbone[24*4*6 ];
public:
	schedule();
	int addClass(int day, int tier,int hour, gtclass* gtclass);
	void printInfo();
	gtclass* getClass(int day, int tier, int hour);
	int addClass(int day, int hour, gtclass* gtclass);
	void exportOutput();
};